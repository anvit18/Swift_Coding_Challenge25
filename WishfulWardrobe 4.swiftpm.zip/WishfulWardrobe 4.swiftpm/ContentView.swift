import SwiftUI

enum WishlistCategory: String, CaseIterable, Identifiable {
    case fashionAndAccessories = "Fashion and Accessories"
    case electronics = "Electronics"
    case homeAndKitchen = "Home and Kitchen"
    case booksAndLearning = "Books and Learning"
    case healthAndFitness = "Health and Fitness"
    case travel = "Travel"
    case hobbiesAndInterests = "Hobbies and Interests"
    case beautyAndSelfCare = "Beauty and Self-Care"
    case techAndGaming = "Tech and Gaming"
    case giftCardsAndExperiences = "Gift Cards and Experiences"
    case financialGoals = "Financial Goals"
    case personalDevelopment = "Personal Development"
    
    var id: WishlistCategory { self }
}

class WishlistViewModel: ObservableObject {
    @Published var wishlist: [WishlistItem] = []
}

struct WishlistItem: Identifiable {
    var id = UUID()
    var title: String
    var link: URL
    var description: String
    var category: WishlistCategory
    var budget: Double
    var achieved: Bool = false
    var goalMonth: String
    var status: String // Added status property
}

struct GoalMonthPicker: View {
    @Binding var selectedGoalMonth: String
    @Binding var isShowingPopover: Bool
    
    var body: some View {
        VStack {
            Text("Select Goal Month")
                .font(.headline)
                .padding()
            
            ForEach(1...12, id: \.self) { month in
                Button(action: {
                    selectedGoalMonth = DateFormatter().monthSymbols[month - 1]
                    isShowingPopover = false
                }) {
                    Text(DateFormatter().monthSymbols[month - 1])
                        .padding()
                }
            }
        }
        .padding()
    }
}

struct ContentView: View {
    @ObservedObject var viewModel = WishlistViewModel()
    
    @State private var isAddingItem = false
    @State private var newItemTitle = ""
    @State private var newItemLink = ""
    @State private var newItemDescription = ""
    @State private var selectedCategory: WishlistCategory? = nil
    @State private var newItemBudget = ""
    @State private var isBudgetInputValid = true
    @State private var selectedGoalMonth = ""
    @State private var selectedItem: WishlistItem? = nil
    @State private var isShowingItemList = false // Added state
    
    var body: some View {
        NavigationView {
            
            VStack {
                
                HStack {
                    Text("WishfulWardrobe")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                        .padding()
                    
                    Spacer()
                    
                    Button(action: {
                        isShowingItemList.toggle() // Toggle the state to show/hide the list
                    }) {
                        Image(systemName: "clock")
                            .foregroundColor(.blue)
                            .font(.title)
                    }
                    .padding(.trailing)
                }
                                    // Show the list when the state is true
                if isShowingItemList {
                    if viewModel.wishlist.isEmpty {
                        Text("Phew, no wishlists! Add an item to view your wishlists!")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        // Show the list when the state is true
                        List {
                            ForEach(viewModel.wishlist) { item in
                                Text("\(item.title) \(item.link) - Status: \(item.status)")
                            }
                        }
                        .padding()
                    }
                } else {
                    ScrollView {
                        // Show the categories and items
                        ForEach(WishlistCategory.allCases.filter { category in
                            viewModel.wishlist.contains(where: { $0.category == category })
                        }, id: \.self) { category in
                            VStack(alignment: .leading) {
                                Text(category.rawValue)
                                    .font(.headline)
                                    .padding()
                                    .foregroundColor(.gray)
                                    .padding(.horizontal)
                                
                                ScrollView(.horizontal, showsIndicators: true) {
                                    HStack(spacing: 16) {
                                        ForEach(viewModel.wishlist.filter { $0.category == category }) { item in
                                            ItemView(viewModel: viewModel, item: item)
                                                .onTapGesture {
                                                    selectedItem = item
                                                }
                                        }
                                    }
                                }
                            }
                            .padding(.bottom)
                        }
                    }
                }
                Spacer()
                
                Button("Add Item") {
                    isAddingItem = true
                }
                .padding()
                .frame(width: 300, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                
                .sheet(isPresented: $isAddingItem) {
                    AddItemView(viewModel: viewModel, isAddingItem: $isAddingItem)
                }
            }
            .padding()
            .navigationBarHidden(true)
            
            // NavigationLink to detailed view
            NavigationLink(
                destination: DetailView(item: selectedItem),
                isActive: Binding(
                    get: { selectedItem != nil },
                    set: { _ in selectedItem = nil }
                )
            ) {
                EmptyView()
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func daysRemaining(for goalMonth: String) -> Int {
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM"
        
        guard let goalDate = dateFormatter.date(from: goalMonth),
              let daysRemaining = Calendar.current.dateComponents([.day], from: currentDate, to: goalDate).day else {
            return 0
        }
        
        return max(daysRemaining, 0)
    }
}

struct ItemView: View {
    @State private var isSelected = false
    @ObservedObject var viewModel: WishlistViewModel
    var item: WishlistItem
    
    var body: some View {
        Spacer()
        VStack(alignment: .leading, spacing: 12) {
            Text("\(item.title)")
                .font(.largeTitle)
                .bold()
            Text("\(item.goalMonth)")
                .foregroundColor(.orange)
                .font(.title)
                .bold()
            Text("\(item.description)")
                .foregroundColor(.black)
                .bold()
            Text("Days Pending: \(daysRemaining(for: item.goalMonth))")
                .foregroundColor(.white)
            Text("Status: \(item.status)")
                .bold()
            Text(" ₹\(String(format: "%.2f", item.budget))")
                .font(.title)
                .foregroundColor(.red)
                .bold()
            
            // Padding between details and buttons
            Spacer().frame(height: 10)
            
            HStack {
                Button(action: markAsComplete) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green)
                        .font(.largeTitle)
                }
                
                Button(action: editItem) {
                    Image(systemName: "pencil.circle.fill")
                        .foregroundColor(.orange)
                        .font(.largeTitle)
                }
                
                Button(action: deleteItem) {
                    Image(systemName: "trash.circle.fill")
                        .foregroundColor(.red)
                        .font(.largeTitle)
                }
            }
            .padding(.top, 10) // Adjust the top padding as needed
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .strokeBorder(isSelected ? Color.blue : Color.clear, lineWidth: 3)
                .background(gradientColor(for: item.status))
                .cornerRadius(20)
                .foregroundColor(.white) // Background color for the item
        )
        .onTapGesture {
            isSelected.toggle()
        }
        .overlay {
            if isSelected {
                VStack {
                    Spacer()
                    // Empty overlay for additional padding
                }
                .padding(60)
            }
        }
        Spacer()
    }
    
    // Rest of your code...
    func daysRemaining(for goalMonth: String) -> Int {
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM"
        
        guard let goalDate = dateFormatter.date(from: goalMonth),
              let daysRemaining = Calendar.current.dateComponents([.day], from: currentDate, to: goalDate).day else {
            return 0
        }
        
        return max(daysRemaining, 0)
    }
    
    func markAsComplete() {
        if let index = viewModel.wishlist.firstIndex(where: { $0.id == item.id }) {
            viewModel.wishlist[index].achieved.toggle()
            viewModel.wishlist[index].status = viewModel.wishlist[index].achieved ? "Complete" : "Pending"
        }
    }
    
    func editItem() {
        // Implement logic to open the form with the selected item's details for editing
        // You can pass the 'item' to the form and pre-fill the fields for editing
    }
    
    func deleteItem() {
        viewModel.wishlist.removeAll { $0.id == item.id }
        isSelected.toggle()
    }
    
    func gradientColor(for status: String) -> LinearGradient {
        if status == "Complete" {
            return LinearGradient(
                gradient: Gradient(colors: [Color.green.opacity(0.8), Color.white.opacity(0.8)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.white.opacity(0.6)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
}

struct DetailView: View {
    var item: WishlistItem?
    
    var body: some View {
        VStack {
            if let item = item {
                Text("Title: \(item.title)")
                Text("Goal Month: \(item.goalMonth)")
                Text("Description: \(item.description)")
                Text("Budget: ₹\(String(format: "%.2f", item.budget))")
                Text("Status: \(item.status)")
            } else {
                Text("No item selected")
            }
            
            Spacer()
            
            HStack {
                Button("Mark as Complete") {
                    // Handle "Mark as Complete"
                }
                .padding()
                
                Button("Delete") {
                    // Handle "Delete"
                }
                .padding()
                
                Button("Edit") {
                    // Handle "Edit"
                }
                .padding()
            }
        }
        .padding()
        .navigationBarTitle("Item Details", displayMode: .inline)
    }
}

struct AddItemView: View {
    @ObservedObject var viewModel: WishlistViewModel
    @Binding var isAddingItem: Bool
    @State private var newItemTitle = ""
    @State private var newItemLink = ""
    @State private var newItemDescription = ""
    @State private var selectedCategory: WishlistCategory? = nil
    @State private var newItemBudget = ""
    @State private var isBudgetInputValid = true
    @State private var selectedGoalMonth = ""
    @State private var isShowingGoalMonthPopover = false
    
    var body: some View {
        Form {
            Section(header: Text("Add Wishlist Item")) {
                TextField("Title", text: $newItemTitle)
                TextField("Link", text: $newItemLink)
                TextField("Description", text: $newItemDescription)
                
                Menu {
                    ForEach(WishlistCategory.allCases) { category in
                        Button(action: {
                            selectedCategory = category
                        }) {
                            Text(category.rawValue)
                        }
                    }
                } label: {
                    Text("Category: \(selectedCategory?.rawValue ?? "")")
                }
                
                HStack {
                    Image(systemName: "rupee")
                    TextField("Budget in ₹", text: $newItemBudget)
                        .keyboardType(.decimalPad)
                        .padding()
                        .onChange(of: newItemBudget) { newValue in
                            isBudgetInputValid = Double(newValue) != nil
                        }
                        .foregroundColor(isBudgetInputValid ? .primary : .red)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(isBudgetInputValid ? Color.primary : Color.red, lineWidth: 1)
                        )
                }
                
                if !isBudgetInputValid {
                    Text("Please enter a valid numeric value for Budget")
                        .foregroundColor(.red)
                        .padding(.top, 4)
                }
                
                HStack {
                    Image(systemName: "calendar")
                    TextField("Goal Month", text: $selectedGoalMonth)
                        .padding()
                        .onTapGesture {
                            isShowingGoalMonthPopover = true
                        }
                }
                .popover(isPresented: $isShowingGoalMonthPopover) {
                    GoalMonthPicker(selectedGoalMonth: $selectedGoalMonth, isShowingPopover: $isShowingGoalMonthPopover)
                }
            }
            
            Button("Add Item") {
                guard !newItemTitle.isEmpty,
                      let link = URL(string: newItemLink),
                      !newItemDescription.isEmpty,
                      selectedCategory != nil,
                      isBudgetInputValid,
                      !selectedGoalMonth.isEmpty else {
                    return
                }
                
                let newItem = WishlistItem(
                    title: newItemTitle,
                    link: link,
                    description: newItemDescription,
                    category: selectedCategory!,
                    budget: Double(newItemBudget) ?? 0.0,
                    goalMonth: selectedGoalMonth,
                    status: "Pending"
                )
                self.viewModel.wishlist.append(newItem)
                
                newItemTitle = ""
                newItemLink = ""
                newItemDescription = ""
                selectedCategory = nil
                newItemBudget = ""
                isBudgetInputValid = true
                selectedGoalMonth = ""
                
                isAddingItem = false
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
